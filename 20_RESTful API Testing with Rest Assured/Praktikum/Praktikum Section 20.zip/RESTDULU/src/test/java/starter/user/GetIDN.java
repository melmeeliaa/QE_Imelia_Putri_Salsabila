package starter.user;

import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;

public class GetIDN {
    @Step("I received valid response status line")
    public void iReceivedValidResponeStatusLine() {
        restAssuredThat(response -> response.statusLine("not found"));
    }
}
