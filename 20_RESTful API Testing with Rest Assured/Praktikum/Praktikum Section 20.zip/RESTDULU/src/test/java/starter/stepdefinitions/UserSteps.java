package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.user.*;

public class UserSteps {
    @Steps
    Get get;
    @Steps
    GetN getN;
    @Steps
    GetID getID;
    @Steps
    GetIDN getIDN;
    @Steps
    Post post;
    @Steps
    PostN postN;
    @Steps
    Put put;
    @Steps
    PutN putN;
    @Steps
    Delete delete;
    @Steps
    DeleteN deleteN;
    @Given("I set GET api endpoints")
    public void iSetGETApiEndpoints() {
        get.iSetGETApiEndpoints();
    }

    @When("I send GET HTTP request")
    public void iSendGETHTTPRequest() {
        get.iSendGETHTTPRequest();
    }

    @Then("I received valid HTTP response code {int}")
    public void iReceivedValidHTTPResponseCode(int arg0) {
        get.iReceivedValidHTTPResponseCode200();
    }

    @And("I received valid data for detail user")
    public void iReceivedValidDataForDetailUser() {
        get.iReceivedValidDataForDetailUser();
    }

    @Given("I set POST api endpoints")
    public void iSetPOSTApiEndpoints() {
        post.iSetPOSTApiEndpoints();
    }

    @When("I send POST HTTP request")
    public void iSendPOSTHTTPRequest() {
        post.iSendPOSTHTTPRequest();
    }

    @Then("I receive valid HTTP response code 201")
    public void iReceiveValidHTTPResponseCode() {
        post.iReceiveValidHTTPResponseCode();
    }

    @And("I receive valid data for new user")
    public void iReceiveValidDataForNewUser() {
        post.iReceiveValidDataForNewUser();
    }

    @Given("I set PUT api endpoints")
    public void iSetPUTApiEndpoints() {
        put.iSetPUTApiEndpoints();

    }

    @When("I send PUT HTTP request")
    public void iSendPUTHTTPRequest() {
        put.iSendPUTHTTPRequest();
    }

    @And("I receive valid data for update user")
    public void iReceiveValidDataForUpdateUser() {
        put.iReceiveValidDataForUpdateUser();
    }

    @Given("I set DELETE api endpoints")
    public void iSetDELETEApiEndpoints() {
        delete.iSetDELETEApiEndpoints();
    }

    @When("I send DELETE HTTP request")
    public void iSendDELETEHTTPRequest() {
        delete.iSendDELETEHTTPRequest();
    }


    @Then("I received valid HTTP response code {int} delete")
    public void iReceivedValidHTTPResponseCodeDelete(int arg0) {
        delete.iReceivedValidHTTPResponseCodeDelete(204);
    }


    @Then("I received valid response content type")
    public void iReceivedValidResponseContentType() {
        getN.iReceivedValidResponseContentType();
    }

    @Then("I receive valid response header")
    public void iReceiveValidHeader() {
        postN.iReceiveValidHeader();
    }

    @Given("I set GET api endpoints by ID")
    public void iSetGETApiEndpointsByID() {
        getID.iSetGETApiEndpointsByID();
    }

    @When("I send GET HTTP request by ID")
    public void iSendGETHTTPRequestByID() {
        getID.iSendGETHTTPRequestByID();
    }

    @Then("I received valid HTTP response code {int} by ID")
    public void iReceivedValidHTTPResponseCodeByID(int arg0) {
        getID.iReceivedValidHTTPResponseCodeByID();
    }

    @And("I received valid data for get data by ID")
    public void iReceivedValidDataForGetDataByID() {
        getID.iReceivedValidDataForGetDataByID();
    }

    @Then("I received valid response status line")
    public void iReceivedValidResponseStatusLine() {
        getIDN.iReceivedValidResponeStatusLine();

    }

    @Then("I received valid time response")
    public void iReceivedValidTimeResponse() {
        putN.iReceivedValidTimeResponse();
    }

    @Then("I received valid response time")
    public void iReceivedValidResponseTime() {
        deleteN.iReceivedValidResponseTime();
    }
}
