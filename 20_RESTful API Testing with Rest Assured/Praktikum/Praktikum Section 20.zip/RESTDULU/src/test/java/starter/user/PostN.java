package starter.user;

import net.thucydides.core.annotations.Step;
import org.json.JSONObject;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;

public class PostN {
    @Step("I receive valid response header")
    public void iReceiveValidHeader() {
        restAssuredThat(response -> response.header("Content-Type", "aplication/json; charset=utf-8"));
    }
}
