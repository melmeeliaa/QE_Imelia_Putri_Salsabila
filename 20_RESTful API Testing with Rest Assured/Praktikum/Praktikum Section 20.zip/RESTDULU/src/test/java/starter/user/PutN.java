package starter.user;

import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;

public class PutN {
    @Step("I received valid time response")
    public void iReceivedValidTimeResponse() {
        restAssuredThat(response -> response.cookie("No cookies"));
    }
}
