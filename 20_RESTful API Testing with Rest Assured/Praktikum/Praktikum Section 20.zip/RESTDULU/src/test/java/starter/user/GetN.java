package starter.user;

import net.thucydides.core.annotations.Step;
import static net.serenitybdd.rest.SerenityRest.restAssuredThat;

public class GetN {
    @Step("I received valid response content type")
    public void iReceivedValidResponseContentType() {
        restAssuredThat(response -> response.contentType("null"));
    }
    }

