package starter.user;

import io.restassured.response.ValidatableResponse;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.rest.SerenityRest.restAssuredThat;

public class DeleteN {


    @Step("I received valid response time")
    public void iReceivedValidResponseTime() {
        restAssuredThat(response -> response.statusCode(200));
    }
}
