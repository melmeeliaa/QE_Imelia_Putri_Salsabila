package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.pages.LoginPage;
import starter.pages.PayPage;
import starter.pages.PilihProduct;

public class KumpulanSteps {

    @Steps
    LoginPage login;
    @Steps
    PilihProduct pilihProduct;
    @Steps
    PayPage pay;

    @Given("user on login page")
    public void userOnLoginPage() {
        login.onLoginPage();
        pilihProduct.onLoginPage();
    }

    @When("user input valid username")
    public void userInputValidUsername() {
        login.inputUserName("standard_user");
    }

    @And("user input valid password")
    public void userInputValidPassword() {
        login.inputPassword("secret_sauce");
    }

    @And("user click login button")
    public void userClickLoginButton() {
        login.clickLoginButton();
    }

    @Then("user on products page")
    public void userOnProductsPage() {
        login.onProductsPage();
    }

    @When("user input invalid username")
    public void userInputInvalidUsername() {
        login.inputInvalidUsername("awan");
    }

    @Then("user see error message")
    public void userSeeErrorMessage() {
        login.errorMessageIsDispalyed();
    }

    @When("user input valid username and password")
    public void userInputValidUsernameAndPassword() {
        pilihProduct.inputUserName("standard_user");
        pilihProduct.inputPassword("secret_sauce");
        pilihProduct.clickLoginButton();
    }

    @Then("user click add product item")
    public void userClickAddProductItem() {
        pilihProduct.klikButtonProduct();
    }

    @And("user click button add product item")
    public void userClickButtonAddProductItem() {
        pilihProduct.klikAddToCartButton();
    }


    @Then("user click button shopping cart")
    public void userClickButtonShoppingCart() {
        pay.clickShoppingCartBtn();
    }

    @And("user click button checkout")
    public void userClickButtonCheckout() {
        pay.clickCheckoutBtn();
    }

    @Then("user input field your information like first name, last name and postal code")
    public void userInputFieldYourInformationLikeFirstNameLastNameAndPostalCode() {
        pay.inputFirstNameField("Imelia Putri");
        pay.inputLastNameField("Salsabila");
        pay.inputPostalCodeField("57126");
    }

    @And("user click button continue")
    public void userClickButtonContinue() {
        pay.clickContinueBtn();
    }

    @Then("user see overview checkout")
    public void userSeeOverviewCheckout() {
        pay.SeeOverviewCheckout();
    }

    @And("User click button finish")
    public void userClickButtonFinish() {
        pay.ClickFinishBtn();
    }
}
