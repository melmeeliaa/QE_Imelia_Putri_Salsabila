package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.pages.LoginPage;
import starter.pages.PilihProduct;

public class KumpulanSteps {

        @Steps
        LoginPage login;
        @Steps
        PilihProduct pilihProduct;

        @Given("user on login page")
        public void userOnLoginPage() {
            login.onLoginPage();
            pilihProduct.onLoginPage();
        }

        @When("user input valid username")
        public void userInputValidUsername(){
            login.inputUserName("standard_user");
        }

        @And("user input valid password")
        public void userInputValidPassword() {
            login.inputPassword("secret_sauce");
        }

        @And("user click login button")
        public void userClickLoginButton()  {
            login.clickLoginButton();
        }

        @Then("user on products page")
        public void userOnProductsPage() {
            login.onProductsPage();
        }

        @When("user input invalid username")
        public void userInputInvalidUsername() {
            login.inputInvalidUsername("awan");
        }

        @Then("user see error message")
        public void userSeeErrorMessage() {
            login.errorMessageIsDispalyed();
        }
    @When("user input valid username and password")
    public void userInputValidUsernameAndPassword() {
            pilihProduct.inputUserName("standard_user");
            pilihProduct.inputPassword("secret_sauce");
            pilihProduct.clickLoginButton();
    }
    @Then("user click add product item")
    public void userClickAddProductItem() { pilihProduct.klikButtonProduct();
    }


}
