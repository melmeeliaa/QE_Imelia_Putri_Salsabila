package starter.pages;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import org.openqa.selenium.By;

    public class LoginPage extends PageObject {

        // =============================== Locator ===============================

        private By SignButton() {
            return By.id("button_signin_home");
        }
        private By emailField() {
            return By.id("email");
        }

        private By passwordField() {
            return By.id("password");
        }


        private By submitLogin() {
            return By.id("submit_login");
        }

        private By errorMessage() {
            return By.id("alert_description");
        }
        //=============================================== Functional ======================================================
        @Step
        public void diHomepageSepulsa() {
            open();
            $(SignButton()).shouldBeVisible();
        }

        @Step
        public void inputEmailValid(String email) {

            $(emailField()).type(email);
        }

        @Step
        public void inputPassword(String password) {
            $(passwordField()).type(password);
        }

        @Step
        public void klikSignButton() {
            $(SignButton()).click();
        }


        @Step
        public void klikSubmitLogin() {
            $(submitLogin()).click();
        }
        @Step
        public void munculErrorMessage() {
            $(errorMessage()).waitUntilVisible();
        }
    }

