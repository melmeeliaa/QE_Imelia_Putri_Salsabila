package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.pages.LoginPage;
import starter.pages.Pembayaran;
import starter.pages.PilihProduk;

public class KumpulanSteps {

        @Steps
        LoginPage login;
        @Steps
        PilihProduk pilihProduk;
        @Steps
        Pembayaran pembayaran;

    @Given("user berada di Homepage Sepulsa")
    public void userBeradaDiHomepageSepulsa() {
        login.diHomepageSepulsa();
    }

    @When("user klik button masuk")
    public void userKlikButtonMasuk() {
        login.klikSignButton();
    }

    @And("user input email valid")
    public void userInputEmailValid() {
        login.inputEmailValid("watikusuma.ina@gmail.com");
    }

    @And("user input password valid")
    public void userInputPasswordValid() {
        login.inputPassword("Imeliacantik30");
    }

    @Then("user klik button masuk kedua")
    public void userKlikButtonMasukKedua() {
        login.klikSubmitLogin();
    }

    @And("user langsung masuk ke homepage sepulsa")
    public void userLangsungMasukKeHomepageSepulsa() {
        System.out.println("User berhasil masuk ke sepulsa");

    }

    @And("user input email invalid")
    public void userInputEmailInvalid() { login.inputEmailValid("xxx.ina@gmail.com");
    }

    @Then("muncul terdapat eror message")
    public void munculTerdapatErorMessage() {
        System.out.println("user akan melihat eror message");

    }

    @And("User masih di login page")
    public void userMasihDiLoginPage() {
    }
    @Given("user berada di Homepage Sepulsa untuk memilih produk")
    public void userAdaDiHomepageSepulsaUntukMemilihProduk() {
        pilihProduk.diHomepageSepulsa();
    }

    @When("user login dengan username dan password yang valid")
    public void userLoginDenganUsernamePasswordYangValid() {
        pilihProduk.klikSignButton();
        pilihProduk.inputEmailValid("watikusuma.ina@gmail.com");
        pilihProduk.inputPassword("Imeliacantik30");
        pilihProduk.klikSubmitLogin();

    }

    @And("user memilih produk dari list produk yang ada")
    public void userMemilihprodukDariListProdukYangAda() {
        System.out.println("Memilih produk pulsa");

    }

    @And("user mengklik produk pulsa")
    public void usermengklikProdukPulsa() {
        pilihProduk.klikButtonPulsa();
    }

    @Then("user memasukkan nomor handphone")
    public void userMemasukkanNoHandphone() {
        pilihProduk.inputPhoneNumber("083879781247");
    }
    @Then("user memilih variasi pulsa")
    public void userMemilihvariasiPulsa() {
        pilihProduk.klikAxisLimaBelasRibu();
    }
    @And("user menuju ke halaman pembayaran")
    public void userMenujukeHalamanPembayaran() {
    }

    @And("User akan melihat detail pembelian dari produk yang dipilih")
    public void userAkanmelihatDetailPembelianDariProdukYangDipilih() {
    }

    @Then("user memasukkan nomor handphone yang invalid")
    public void userMemasukkanNomorHandphoneYangInvalid() {
        pilihProduk.inputPhoneNumber("08387978124768");
    }

    @And("User akan melihat pesan eror no handphone kelebihan")
    public void userAkanMelihatPesanErorNoHandphoneKelebihan() {
        System.out.println("nomornya kelebihan ya");
    }

    @Given("user berada di Homepage Sepulsa untuk memilih Produk")
    public void userBeradaDiHomepageSepulsaUntukMemilihProduk() {
        pembayaran.diHomepageSepulsa();
    }

    @When("user login dengan username dan password yang Valid")
    public void userLoginDenganUsernameDanPasswordYangValid() {
        pembayaran.klikSignButton();
        pembayaran.inputEmailValid("watikusuma.ina@gmail.com");
        pembayaran.inputPassword("Imeliacantik30");
        pembayaran.klikSubmitLogin();
    }

    @And("user memilih produk dari list produk yang Ada")
    public void userMemilihProdukDariListProdukYangAda() {  System.out.println("Memilih produk pulsa");
    }

    @And("user mengklik produk Pulsa")
    public void userMengklikProdukPulsa() { pembayaran.klikButtonPulsa();
    }

    @Then("user memasukkan nomor Handphone")
    public void userMemasukkanNomorHandphone() { pembayaran.inputPhoneNumber("083879781247");
    }

    @Then("user memilih variasi Pulsa")
    public void userMemilihVariasiPulsa() { pembayaran.klikAxisLimaBelasRibu();
    }

    @And("user menuju ke halaman Pembayaran")
    public void userMenujuKeHalamanPembayaran() {
    }

    @And("User akan melihat detail pembelian dari produk yang Dipilih")
    public void userAkanMelihatDetailPembelianDariProdukYangDipilih() {
    }
}

