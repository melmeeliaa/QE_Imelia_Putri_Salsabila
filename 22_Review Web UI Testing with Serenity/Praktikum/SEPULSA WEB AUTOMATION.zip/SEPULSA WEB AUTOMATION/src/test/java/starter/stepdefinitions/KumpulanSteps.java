package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.pages.LoginPage;
import starter.pages.PembayaranPage;
import starter.pages.PilihProduk;

public class KumpulanSteps {

        @Steps
        LoginPage login;
        @Steps
        PilihProduk pilihProduk;
        @Steps
        PembayaranPage bayar;

    @Given("user berada di Homepage Sepulsa")
    public void userBeradaDiHomepageSepulsa() {
        login.diHomepageSepulsa();
    }

    @When("user klik button masuk")
    public void userKlikButtonMasuk() {
        login.klikSignButton();
    }

    @And("user input email valid")
    public void userInputEmailValid() {
        login.inputEmailValid("watikusuma.ina@gmail.com");
    }

    @And("user input password valid")
    public void userInputPasswordValid() {
        login.inputPassword("Imeliacantik30");
    }

    @Then("user klik button masuk kedua")
    public void userKlikButtonMasukKedua() {
        login.klikSubmitLogin();
    }

    @And("user langsung masuk ke homepage sepulsa")
    public void userLangsungMasukKeHomepageSepulsa() {

    }

    @And("user input email invalid")
    public void userInputEmailInvalid() { login.inputEmailValid("xxx.ina@gmail.com");
    }

    @Then("muncul terdapat eror message dan user masih di login page")
    public void munculTerdapatErorMessagedanUserMasihdiLoginPage() {
        login.munculErrorMessage();

    }

    @Given("user berada di Homepage Sepulsa untuk memilih Produk")
    public void userBeradaDiHomepageSepulsaUntukMemilihProduk() {
        pilihProduk.diHomepageSepulsa();
    }
    @Then("user login dengan username dan password yang valid")
    public void userLoginDenganUsernamePasswordYangValid() {
        pilihProduk.klikSignButton();
        pilihProduk.inputEmailValid("watikusuma.ina@gmail.com");
        pilihProduk.inputPassword("Imeliacantik30");
        pilihProduk.klikSubmitLogin();
    }
    @And("user berhasil login")
    public void userBerhasilLogin() {
        pilihProduk.munculSuccessMessage();

    }

    @And("user mengklik produk pulsa")
    public void usermengklikProdukPulsa() {
        pilihProduk.klikButtonPulsa();
    }

    @Then("user memasukkan nomor handphone")
    public void userMemasukkanNoHandphone() {
        pilihProduk.inputPhoneNumber("083879781247");
    }
    @Then("user memilih variasi pulsa")
    public void userMemilihvariasiPulsa() {
        pilihProduk.klikAxisLimaRibu();
    }

    @Then("user memasukkan nomor handphone yang invalid")
    public void userMemasukkanNomorHandphoneYangInvalid() {
        pilihProduk.inputPhoneNumber("08387978124768");
    }

    @Then("user menerima error message")
    public void userMenerimaErrorMessage() { pilihProduk.munculErrorMessage();
    }

    @Given("user melakukan tes fitur pilih produk hingga berhasil")
    public void userMelakukanTesFiturPilihProdukHinggaBerhasil() {
        bayar.diHomepageSepulsa();
        bayar.klikSignButton();
        bayar.inputEmailValid("watikusuma.ina@gmail.com");
        bayar.inputPassword("Imeliacantik30");
        bayar.klikSubmitLogin();
        bayar.munculSuccessMessage();
        bayar.klikButtonPulsa();
        bayar.inputPhoneNumber("083879781247");
        bayar.klikAxisLimaRibu();
    }
    @Then("user memilih metode pembayaran invalid")
    public void userMemilihMetodePembayaran() { bayar.pilihMetodePembayaran();
    }


    @And("user mengklik bayar sekarang")
    public void userMengklikBayarSekarang() { bayar.klikBayarSekarang();
    }

    @Then("user menemukan halaman {int}")
    public void userMenemukanHalaman(int arg0) { bayar.dihalaman404();
    }

    @When("user memilih metode pembayaran valid")
    public void userMemilihMetodePembayaranValid() { bayar.pilihMetodePembayaranValid();
    }

    @Then("user menginput nomor dana")
    public void userMenginputNomorDana() { bayar.inputPhoneNumberDana("083879781247");
    }

    @And("user klik continue")
    public void userKlikContinue() { bayar.klikContinue();
    }
}

