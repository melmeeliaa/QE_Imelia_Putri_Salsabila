package starter.pages;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import org.openqa.selenium.By;

public class PembayaranPage extends PageObject {
    // =============================== Locator ===============================
    private By emailField() {
        return By.id("email");
    }

    private By passwordField() {
        return By.id("password");
    }

    private By SignButton() {
        return By.id("button_signin_home");
    }

    private By submitLogin() {
        return By.id("submit_login");
    }
    private By successMessage() {
        return By.id("message-id");
    }

    private By buttonPulsa() {
        return By.id("Pulsa");
    }

    private By phoneNumber() {
        return By.id("phone_number");
    }

    private By pilihVariasi() {
        return By.xpath("//p[@productname='Axis Rp5.000']");
    }

    //=============================================== Functional ======================================================
    @Step
    public void diHomepageSepulsa() {
        open();
        $(SignButton()).shouldBeVisible();
    }
    @Step
    public void inputEmailValid(String email) {

        $(emailField()).type(email);
    }

    @Step
    public void inputPassword(String password) {

        $(passwordField()).type(password);
    }
    @Step
    public void klikSignButton() {
        $(SignButton()).click();
    }


    @Step
    public void klikSubmitLogin() {
        $(submitLogin()).click();
    }
    @Step
    public void munculSuccessMessage() {
        $(successMessage()).waitUntilVisible();
    }

    @Step
    public void klikButtonPulsa() {
        $(buttonPulsa()).click();
    }
    @Step
    public void inputPhoneNumber(String number) {
        $(phoneNumber()).type(number);
    }
    @Step
    public void klikAxisLimaRibu() {
        $(pilihVariasi()).click();
    }



    // =============================== Locator ===============================
    private By Shopeepay() {
        return By.id("checkbox ShopeePay");
    }
    private By buttonBayar() {
        return By.id("submit_payment");
    }
    private By errorPage() {
        return By.xpath("//a[@class='es-button nt-regular nt-normal']");
    }
    private By DanaCheckBox() {
        return By.id("checkbox DANA"); }
    private By noPhoneField() {
        return By.xpath("//input[@class='txt-input-phone-number-field']");
    }
    private By Continue() {
        return By.xpath("//button[@class='btn-continue btn btn-primary']"); }
    //=============================================== Functional ======================================================

    @Step
    public void pilihMetodePembayaran() {
        $(Shopeepay()).click();
    }
    @Step
    public void klikBayarSekarang() {
        $(buttonBayar()).click();
    }
    @Step
    public void dihalaman404() {
        $(errorPage()).click();
    }
    @Step
    public void pilihMetodePembayaranValid() {
        $(DanaCheckBox()).click();}
    @Step
    public void inputPhoneNumberDana(String number) {
        $(noPhoneField()).type(number);
    }
    @Step
    public void klikContinue() {
        $(Continue()).click();}
}