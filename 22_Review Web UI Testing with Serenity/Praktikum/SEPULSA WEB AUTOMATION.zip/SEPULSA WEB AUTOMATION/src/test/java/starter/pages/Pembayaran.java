package starter.pages;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import org.openqa.selenium.By;

public class Pembayaran extends PageObject {

        // =============================== Locator ===============================
        private By emailField() {
            return By.id("email");
        }

        private By passwordField() {
            return By.id("password");
        }

        private By SignButton() {
            return By.id("button_signin_home");
        }

        private By submitLogin() {
            return By.id("submit_login");
        }

        private By buttonPulsa() {
            return By.id("Pulsa");
        }

        private By phoneNumber() {
            return By.id("phone_number");
        }

        private By pilihVariasi() {
            return By.id("Axis Rp15.000");
        }
        //=============================================== Functional ======================================================
        @Step
        public void diHomepageSepulsa() {
            open();
            $(SignButton()).shouldBeVisible();
        }
        @Step
        public void inputEmailValid(String email) {

            $(emailField()).type(email);
        }

        @Step
        public void inputPassword(String password) {

            $(passwordField()).type(password);
        }
        @Step
        public void klikSignButton() {
            $(SignButton()).click();
        }


        @Step
        public void klikSubmitLogin() {
            $(submitLogin()).click();
        }

        @Step
        public void klikButtonPulsa() {
            $(buttonPulsa()).click();
        }
        @Step
        public void inputPhoneNumber(String number) {
            $(phoneNumber()).type(number);
        }
        @Step
        public void klikAxisLimaBelasRibu() {
            $(pilihVariasi()).click();
        }

    }

